

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rakesh
 */
public class part6 extends HttpServlet {
    String ans1;
    String ans2;
    String ans3;
    String ans4;

public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
sendPage1(response);
}
public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
String page = request.getParameter("page");
 ans1=request.getParameter("ques1");
 ans2=request.getParameter("ques2");
 ans3=request.getParameter("ques3");
 ans4=request.getParameter("ques4");


if (page == null) {
sendPage1(response);
return;
}
if (page.equals("1")) {
 sendPage2(response);
}
else if (page.equals("2")) {
 sendPage3(response);
}
else if (page.equals("3")) {
 sendPage4(response);
}
else if (page.equals("4")) {
 displayValues(response);
}
 }
void sendPage1(HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Page 1</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Page 1</H2>");
out.println("Question 1<BR><BR>");
out.println("<FORM METHOD=POST>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=1>");
out.println("Grand Central Terminal, Park Avenue, New York is the world's<BR><BR>");
out.println("<INPUT name='ques1' type='radio' value='largest railway station'>largest railway station</BR>");
out.println("<INPUT name='ques1' type='radio' value='longest railway station'>longest railway station</BR>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY>");
out.println("</HTML>");
 }
 
 void sendPage2(HttpServletResponse response) throws ServletException, IOException
 {
response.setContentType("text/html");
PrintWriter out = response.getWriter();

out.println("<HTML>");
out.println("<HEAD><TITLE>Page 2</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Page 2</H2>");
out.println("Question 2<BR><BR>");
out.println("<FORM ACTION='part6' METHOD=POST>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=2>");
out.println("Entomology is the science that studies<BR><BR>");
out.println("<INPUT name='ques2' type='radio' value='Insects'>Insects</BR>");
out.println("<INPUT name='ques2' type='radio' value='The formation of rocks'>The formation of rocks</BR>");
out.println("<INPUT TYPE=HIDDEN NAME=ques1 VALUE='"+ans1+"'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY></HTML>");
 }
 
void sendPage3(HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Page 3</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<CENTER>");
out.println("<H2>Page 3</H2>");
out.println("Question 3<BR><BR>");
out.println("<FORM METHOD=POST>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=3>");
out.println("Hitler party which came into power in 1933 is known as<BR><BR>");
out.println("<INPUT name='ques3' type='radio' value='Ku-Klux-Klan'>Ku-Klux-Klan</BR>");
out.println("<INPUT name='ques3' type='radio' value='Nazi Party'>Nazi Party</BR>");
out.println("<INPUT TYPE=HIDDEN NAME=ques1 VALUE='"+ans1+"'>");
out.println("<INPUT TYPE=HIDDEN NAME=ques2 VALUE='"+ans2+"'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY></HTML>");
 }

void sendPage4(HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Page 4</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<CENTER>");
out.println("<H2>Page 4</H2>");
out.println("Question 4<BR><BR>");
out.println("<FORM METHOD=POST>");
out.println("<INPUT TYPE=HIDDEN NAME=page VALUE=4>");
out.println("For which of the following disciplines is Nobel Prize awarded?<BR><BR>");
out.println("<INPUT name='ques4' type='radio' value='Physics and Chemistry'>Physics and Chemistry</BR>");
out.println("<INPUT name='ques4' type='radio' value='Human Science'>Human Science</BR>");
out.println("<INPUT TYPE=HIDDEN NAME=ques1 VALUE='"+ans1+"'>");
out.println("<INPUT TYPE=HIDDEN NAME=ques2 VALUE='"+ans2+"'>");
out.println("<INPUT TYPE=HIDDEN NAME=ques3 VALUE='"+ans3+"'>");
out.println("<TD><INPUT TYPE=SUBMIT VALUE=Submit></TD>");
out.println("</FORM>");
out.println("</CENTER>");
out.println("</BODY></HTML>");
 }

void displayValues(HttpServletResponse response) throws ServletException, IOException {
response.setContentType("text/html");
PrintWriter out = response.getWriter();
out.println("<HTML>");
out.println("<HEAD><TITLE>Page 5</TITLE></HEAD>");
out.println("<BODY>");
out.println("<CENTER>");
out.println("<H2>Page 5 (Finish)</H2>");
out.println("Here are the values you have entered.<BR><BR>");
out.println("Answer 1 :");
out.println(ans1 +"</BR>");
out.println("Answer 2 :");
out.println(ans2+ "</BR>");
out.println("Answer 3 :");
out.println(ans3+ "</BR>");
out.println("Answer 4 :");
out.println(ans4+ "</BR>");
out.println("</CENTER>");
out.println("</BODY></HTML>");
 } 

} 

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
  

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */



