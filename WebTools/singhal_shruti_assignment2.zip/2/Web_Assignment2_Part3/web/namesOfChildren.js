/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */


/* global noOfChild, hidden */

 function namesOfChildren(){
    alert("HELLO");
    document.getElementById(noOfChild).style.visibility=hidden;
    document.getElementById(nameOfChild).style.visibility=visible;
    var x=document.getElementById(number).value;
    for(var i=0;i<x;i++){
        var newparah= document.createElement(p);
        newparah.innerHTML="What is the name of your child"+i+ <input type=text name=childname>;
        document.getElementById(nameOfChild).appendChild(newparah);
    }
    
    var button=document.createElement(input);
    button.setAttribute(type,submit);
    document.getElementById(nameOfChild).appendChild(button);
 }
out.println("document.getElementById(noOfChild).style.visibility=hidden;");
out.println("    document.getElementById(nameOfChild).style.visibility=visible;");
out.println("    var x=document.getElementById(number).value;");
out.println("    for(var i=0;i<x;i++){");
out.println("        var newparah= document.createElement(p);");
out.println("        newparah.innerHTML=\"What is the name of your child\"+i+ <input type=text name=childname>;");
out.println("        document.getElementById(nameOfChild).appendChild(newparah);");
out.println("    }");
out.println("    ");
out.println("    var button=document.createElement(input);");
out.println("    button.setAttribute(type,submit);");
out.println("    document.getElementById(nameOfChild).appendChild(button);");
