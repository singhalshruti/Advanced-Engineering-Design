/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author Rakesh
 */
public class part3 extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            
            /* TODO output your page here. You may use following sample code. */
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Assignment2 Part3</title>");
out.println("<script>");
            out.println("function namesOfChildren(){");
            out.println("alert('hey');");
            out.println("document.getElementById('noOfChild').style.display='none';");
            out.println("    document.getElementById('nameOfChild').style.display='block';");
            out.println("    var x=document.getElementById('number').value;");
            out.println("    for(var i=1;i<=x;i++){");
            out.println("        var newparah= document.createElement('p');");
            out.println("        newparah.innerHTML=\"What is the name of your child \"+i+\" <input type=text name='childname'>\";");
            out.println("        document.getElementById('nameOfChild').appendChild(newparah);");
            out.println("    }");
            out.println("    ");
            out.println("    var button=document.createElement('input');");
            out.println("    button.setAttribute('type','submit');");
            out.println("    document.getElementById('nameOfChild').appendChild(button);");
            out.println("}");
            out.println("</script>");            
            out.println("</head>");
            out.println("<body>");
            out.println("<FORM ACTION='' ROLE='ROLE' METHOD='POST'>");
            out.println("<div id=noOfChild>");
            out.println("How many children do you have? </BR>");
            out.println("<INPUT TYPE='TEXT' NAME='number' ID='number'></BR>");
            out.println("<INPUT TYPE='BUTTON' VALUE='SubmitQuery' ID='submit' ONCLICK='namesOfChildren()'>");
            out.println("</div>");
            out.println("<div id=nameOfChild>");
            out.println("</div>");
            out.println("</FORM>");
            
            //out.println("<h1>Servlet part3 at " + request.getContextPath() + "</h1>");
            out.println("</body>");
            out.println("</html>");
        }
    }
    


    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
   

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
@Override
protected void doPost(HttpServletRequest request,
 HttpServletResponse response)
 throws ServletException, IOException {
 

	response.setContentType("text/html");
	PrintWriter out = response.getWriter();
        Enumeration kids=request.getParameterNames();

		out.println("<html>");
		out.println("<head>");
		out.println("<title> Children's names</title>");
		out.println("</head>");
                out.println("<h1> Your Children's names are: </h1>");
		out.println("<body>");
                while (kids.hasMoreElements()){
                    
                    String nameOfKids=(String)kids.nextElement();
                    String[] n=request.getParameterValues(nameOfKids);
                    
            for (String n1 : n) {
                out.println("<LI>" + n1);
            }
                }

		out.println("</body>");
		out.println("</html>");
    }
}
