/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.Controller;

import com.neu.edu.Dao.BookDAO;
import com.neu.edu.Pojo.Book;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.Controller;

/**
 *
 * @author Rakesh
 */
public class HomeController implements Controller {

    
    BookDAO bookDAO;

    public HomeController(BookDAO bookDAO) {
        
        this.bookDAO = bookDAO;

    }

    @Override
    public ModelAndView handleRequest(HttpServletRequest request, HttpServletResponse hsr1) throws Exception {
         //To change body of generated methods, choose Tools | Templates.
    
        HttpSession session = request.getSession();
        String action = request.getParameter("action");
        ModelAndView mv = new ModelAndView();
        
        
        if (action.equals("success")) {
            
            String count=(String) session.getAttribute("count");
            int c=(Integer.parseInt(count));
            
        try{    
             String[] ISBN =  request.getParameterValues("ISBN");
             String[] title=request.getParameterValues("BookTitle");
             String[] author=request.getParameterValues("Author");
             String[] cost = request.getParameterValues("Cost");
            
            
            ArrayList<Book>listOfBooks= new ArrayList<>();
             
             for(int i=0; i<c; i++){
                 Book b=new Book();
                 b.setISBN(ISBN[i]);
                 b.setTitle(title[i]);
                 b.setCost(Float.parseFloat(cost[i]));
                 b.setAuthorName(author[i]);
                 
                 listOfBooks.add(b);
             }
              bookDAO.addBook(listOfBooks);
        }
        catch(Exception e){
            System.out.println(e.getMessage());
        }
            
        
        
             mv.setViewName("BooksAdded");
        }
       
        else if(action.equals("addBooks")){
            String c = request.getParameter("no");
            session.setAttribute("count", c);
            mv.setViewName("BookDetails"); 
            
            
        }
        else if(action.equals("firstPage")){
            mv.setViewName("index");
        }
        return mv;
    }
    
}
