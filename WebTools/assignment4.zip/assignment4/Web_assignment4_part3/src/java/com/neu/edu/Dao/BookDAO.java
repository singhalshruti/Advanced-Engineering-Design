/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.Dao;

import com.neu.edu.Pojo.Book;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rakesh
 */
public class BookDAO extends DAO{
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    //int count=0;
    public void addBook(ArrayList<Book> listOfBooks) throws SQLException {

        
        

        try {
            conn = getConnection();
            for(Book book:listOfBooks){
            String query ="insert into book (ISBN,title,authorName,cost) values(?,?,?,?)";
            ps = conn.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setString(1, book.getISBN());
            ps.setString(2, book.getTitle());
            ps.setString(3, book.getAuthorName());
            ps.setFloat(4,(book.getCost()));
            
            
           
            int result = ps.executeUpdate();
            //count++;
           
        } }
        catch (SQLException ex) {
            Logger.getLogger(BookDAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            close(conn);
            ps.close();
            rs.close();
        

        //return count;
    }
    }
    
    
  
}
