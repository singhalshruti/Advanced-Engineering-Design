/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.DAO;

import com.neu.edu.pojo.SalesOrder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rakesh
 */
public class SalesOrderDAO extends DAO{
    
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    //int count=0;
    public ArrayList getCSVValues() throws SQLException {
        conn = getDriverConnection();
        ArrayList<SalesOrder> salesOrderList =  new ArrayList<>();
        try {
           Statement stmt = conn.createStatement();


            ResultSet results = stmt.executeQuery("SELECT * FROM SalesOrder1");

            while(results.next()){
                SalesOrder so= new SalesOrder();
           
             so.setSalesOrderID(results.getInt("SalesOrderID"));
       so.setRevisionNumber(results.getInt("RevisionNumber"));   
       so.setOrderDate(results.getString("OrderDate"));   
       so.setDueDate(results.getString("DueDate"));   
       so.setShipDate(results.getString("ShipDate"));   
       so.setStatus(results.getInt("Status"));   
       so.setOnlineOrderFlag(results.getString("OnlineOrderFlag"));   
       so.setSalesOrderNumber(results.getString("SalesOrderNumber"));   
       so.setPurchaseOrderNumber(results.getString("PurchaseOrderNumber"));   
       so.setAccountNumber(results.getString("AccountNumber"));   
       so.setCustomerID(results.getInt("CustomerID"));   
       so.setSalesPersonID(results.getInt("SalesPersonID"));   
       so.setTerritoryID(results.getInt("TerritoryID"));   
       so.setBillToAddressID(results.getInt("BillToAddressID"));   
       so.setShipToAddressID(results.getInt("ShipToAddressID"));   
       so.setShipMethodID(results.getInt("ShipMethodID"));   
       so.setCreditCardID(results.getInt("CreditCardID"));   
       so.setCreditCardApprovalCode(results.getString("CreditCardApprovalCode"));
       so.setCurrencyRateID(results.getString("CurrencyRateID"));
       so.setSubTotal(results.getFloat("SubTotal"));
       so.setTaxAmt(results.getFloat("TaxAmt"));
       so.setFreight(results.getFloat("Freight"));
       so.setTotalDue(results.getFloat("TotalDue"));
       so.setComment(results.getString("Comment"));
       so.setModifiedDate(results.getString("ModifiedDate"));
       salesOrderList.add(so);                     
                                       } 
            close(conn);
        }
        catch (SQLException ex) {
            Logger.getLogger(SalesOrder.class.getName()).log(Level.SEVERE, null, ex);
        } 
      
        return salesOrderList;

        //return count;
    }
    }
 

