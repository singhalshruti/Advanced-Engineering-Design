/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.servlet;

import com.neu.edu.DAO.DAO;
import com.neu.edu.DAO.SalesOrderDAO;
import com.neu.edu.pojo.SalesOrder;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import static org.apache.commons.dbutils.DbUtils.close;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Rakesh
 */
public class AbstractControllerNew extends AbstractController {
    SalesOrderDAO salesOrderDAO;
   
    public AbstractControllerNew(SalesOrderDAO salesOrderDAO) {
        this.salesOrderDAO = salesOrderDAO;
    }
    ArrayList<SalesOrder> salesOrderList  = new ArrayList<>();
    PreparedStatement ps;
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
           
           ModelAndView mv = new ModelAndView();
           String file = request.getParameter("fileName");
           String action = request.getParameter("action");
           HttpSession session = request.getSession();
 
        
        if( action.equals("printFileValue")){
        mv.setViewName("mytag");
        }
           
        if( action.equals("display")){
        
        Connection conn = salesOrderDAO.getConnection();
        
        salesOrderList = salesOrderDAO.getCSVValues();
        try 
        {
            for(SalesOrder salesOrder:salesOrderList)
            {
            
                String query ="insert into salesOrder " + "(SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comm, ModifiedDate) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, salesOrder.getSalesOrderID());
            ps.setInt(2, salesOrder.getRevisionNumber());
            ps.setString(3, salesOrder.getOrderDate());
            ps.setString(4, salesOrder.getDueDate());
            ps.setString(5, salesOrder.getShipDate());
            ps.setInt(6, salesOrder.getStatus());
            ps.setString(7, salesOrder.getOnlineOrderFlag());
            ps.setString(8, salesOrder.getSalesOrderNumber());
            ps.setString(9, salesOrder.getPurchaseOrderNumber());
            ps.setString(10,(salesOrder.getAccountNumber()));
            ps.setInt(11, salesOrder.getCustomerID());
            ps.setInt(12, salesOrder.getSalesPersonID());
            ps.setInt(13, salesOrder.getTerritoryID());
            ps.setInt(14, salesOrder.getBillToAddressID());
            ps.setInt(15, salesOrder.getShipToAddressID());
            ps.setInt(16, salesOrder.getShipMethodID());
            ps.setInt(17, salesOrder.getCreditCardID());
            
            ps.setString(18, salesOrder.getCreditCardApprovalCode());
            ps.setString(19,salesOrder.getCurrencyRateID());
            ps.setFloat(20, salesOrder.getSubTotal());
            ps.setFloat(21, salesOrder.getTaxAmt());
            ps.setFloat(22, salesOrder.getFreight());
            ps.setFloat(23, salesOrder.getTotalDue());
            ps.setString(24, salesOrder.getComment());
            ps.setString(25,(salesOrder.getModifiedDate()));
            
            int result = ps.executeUpdate();
                  
        }
    } catch (SQLException ex) {
            Logger.getLogger(DAO.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            close(conn);
            ps.close();   
        }
                String sucess = "true";
                session.setAttribute("sucess", sucess);
                mv.setViewName("sucess");
                session.removeAttribute("salesList");
        }
        
        return mv;
    }}
    

