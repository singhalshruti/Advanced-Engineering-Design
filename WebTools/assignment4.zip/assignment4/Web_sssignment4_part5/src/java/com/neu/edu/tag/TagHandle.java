/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.tag;
import com.neu.edu.DAO.DAO;
import com.neu.edu.pojo.SalesOrder;
import java.io.IOException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.SimpleTagSupport;

/**
 *
 * @author Rakesh
 */
public class TagHandle extends SimpleTagSupport {
 
   
  
    
    DAO SalesDao = new DAO() ;
    ArrayList<SalesOrder>  salesOrderList ;
    private String list;// need to pass this and display in JSP Page
   

   
  public void doTag() throws JspException{
        try {
          
            salesOrderList =  (ArrayList<SalesOrder>) SalesDao.getDriverConnection();
            display(salesOrderList);
        } catch (Exception ex) {
            Logger.getLogger(TagHandle.class.getName()).log(Level.SEVERE, null, ex);
        }
  }  
  private void display (ArrayList salesOrderList)throws JspException{
    JspWriter out = getJspContext().getOut();
     this.getJspContext().setAttribute("list",list);
          try{
            out.print("Sales Order");
          //for(int i =0 ;i<csvList.size();i++)
            for(int i =0 ;i<3;i++)
          {
          SalesOrder so =  (SalesOrder)salesOrderList.get(i);
        
          out.print("<TABLE>");
          out.print("<TR>");        
          out.print("<TD>"+so.getSalesOrderNumber()+"</TD>"); 
          out.println("</TR>");
          out.println("</TABLE>");
          }
          
          }catch(IOException ex )
  
          {ex.printStackTrace();}
  
  }
   
   public void setList(ArrayList<SalesOrder> salesOrderList) {
        this.salesOrderList = salesOrderList;
    }
    
}
