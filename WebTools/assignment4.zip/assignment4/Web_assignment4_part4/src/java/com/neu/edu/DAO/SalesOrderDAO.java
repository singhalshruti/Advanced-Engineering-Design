/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.DAO;

import com.neu.edu.Pojo.SalesOrder;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Rakesh
 */
public class SalesOrderDAO extends DAO{
    
    Connection conn;
    PreparedStatement ps;
    ResultSet rs;
    //int count=0;
    public void addSalesOrder(ArrayList<SalesOrder> salesOrderList) throws SQLException {
        try {
            conn = getConnection();
            
            for(SalesOrder salesOrder:salesOrderList)
            {
            String query ="insert into salesOrder " + "(SalesOrderID, RevisionNumber, OrderDate, DueDate, ShipDate, Status, OnlineOrderFlag, SalesOrderNumber, PurchaseOrderNumber, AccountNumber, CustomerID, SalesPersonID, TerritoryID, BillToAddressID, ShipToAddressID, ShipMethodID, CreditCardID, CreditCardApprovalCode, CurrencyRateID, SubTotal, TaxAmt, Freight, TotalDue, Comm, ModifiedDate) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
            ps = conn.prepareStatement(query,PreparedStatement.RETURN_GENERATED_KEYS);
            ps.setInt(1, salesOrder.getSalesOrderID());
            ps.setInt(2, salesOrder.getRevisionNumber());
            ps.setString(3, salesOrder.getOrderDate());
            ps.setString(4, salesOrder.getDueDate());
            ps.setString(5, salesOrder.getShipDate());
            ps.setInt(6, salesOrder.getStatus());
            ps.setString(7, salesOrder.getOnlineOrderFlag());
            ps.setString(8, salesOrder.getSalesOrderNumber());
            ps.setString(9, salesOrder.getPurchaseOrderNumber());
            ps.setString(10,(salesOrder.getAccountNumber()));
            ps.setInt(11, salesOrder.getCustomerID());
            ps.setInt(12, salesOrder.getSalesPersonID());
            ps.setInt(13, salesOrder.getTerritoryID());
            ps.setInt(14, salesOrder.getBillToAddressID());
            ps.setInt(15, salesOrder.getShipToAddressID());
            ps.setInt(16, salesOrder.getShipMethodID());
            ps.setInt(17, salesOrder.getCreditCardID());
            
            ps.setString(18, salesOrder.getCreditCardApprovalCode());
            ps.setString(19,salesOrder.getCurrencyRateID());
            ps.setFloat(20, salesOrder.getSubTotal());
            ps.setFloat(21, salesOrder.getTaxAmt());
            ps.setFloat(22, salesOrder.getFreight());
            ps.setFloat(23, salesOrder.getTotalDue());
            ps.setString(24, salesOrder.getComment());
            ps.setString(25,(salesOrder.getModifiedDate()));
            
            int result = ps.executeUpdate();
            //count++;
           
        } 
        }
        catch (SQLException ex) {
            Logger.getLogger(SalesOrder.class.getName()).log(Level.SEVERE, null, ex);
        } 
        finally {
            close(conn);
            ps.close();
        

        //return count;
    }
    }
 
}
