/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.neu.edu.Controller;

import com.neu.edu.DAO.SalesOrderDAO;
import com.neu.edu.Pojo.SalesOrder;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.util.ArrayList;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.AbstractController;

/**
 *
 * @author Rakesh
 */
public class AbstractControllerNew extends AbstractController {
    SalesOrderDAO salesOrderDAO;
    public AbstractControllerNew(SalesOrderDAO salesOrderDAO) {
        this.salesOrderDAO = salesOrderDAO;
    }
    
    protected ModelAndView handleRequestInternal(
            HttpServletRequest request,
            HttpServletResponse response) throws Exception {
           
           ModelAndView mv = new ModelAndView();
           String file = request.getParameter("fileName");
           String a = request.getParameter("todo");
           HttpSession session = request.getSession();
 
        String s = "value";
        session.setAttribute("value", s);
        
        
    
     try{
          if (a.equalsIgnoreCase("insert")) {
         
            if (session.getAttribute("salesOrderList") != null) {
                ArrayList<SalesOrder> salesList = (ArrayList<SalesOrder>) session.getAttribute("salesOrderList");
                salesOrderDAO.addSalesOrder(salesList);
               
                String updated = "true";
                session.setAttribute("updated", updated);
                mv.setViewName("index");
                session.removeAttribute("salesOrderList");
                
            }
                
        }}
        catch(Exception e){
            System.out.println(e.getMessage());
        }
             
    try
    {
        if (a.equalsIgnoreCase("fileValues")) { 
      // Load the driver.
      Class.forName("org.relique.jdbc.csv.CsvDriver");
      Connection conn = (Connection) DriverManager.getConnection("jdbc:relique:csv:C:\\Users\\Rakesh\\Documents");
      Statement stmt = (Statement) conn.createStatement();
      // Select the ID and NAME columns from sample.csv
      ResultSet results = stmt.executeQuery("SELECT * FROM " +file);

      ResultSetMetaData metadata = results.getMetaData();
      int numberOfColumns = metadata.getColumnCount();
      
      ArrayList<SalesOrder> salesOrderList = new ArrayList<>(); 
      while 
              (results.next()) {              
       SalesOrder so = new SalesOrder();
        
       so.setSalesOrderID(results.getInt("SalesOrderID"));
       so.setRevisionNumber(results.getInt("RevisionNumber"));   
       so.setOrderDate(results.getString("OrderDate"));   
       so.setDueDate(results.getString("DueDate"));   
       so.setShipDate(results.getString("ShipDate"));   
       so.setStatus(results.getInt("Status"));   
       so.setOnlineOrderFlag(results.getString("OnlineOrderFlag"));   
       so.setSalesOrderNumber(results.getString("SalesOrderNumber"));   
       so.setPurchaseOrderNumber(results.getString("PurchaseOrderNumber"));   
       so.setAccountNumber(results.getString("AccountNumber"));   
       so.setCustomerID(results.getInt("CustomerID"));   
       so.setSalesPersonID(results.getInt("SalesPersonID"));   
       so.setTerritoryID(results.getInt("TerritoryID"));   
       so.setBillToAddressID(results.getInt("BillToAddressID"));   
       so.setShipToAddressID(results.getInt("ShipToAddressID"));   
       so.setShipMethodID(results.getInt("ShipMethodID"));   
       so.setCreditCardID(results.getInt("CreditCardID"));   
       so.setCreditCardApprovalCode(results.getString("CreditCardApprovalCode"));
       so.setCurrencyRateID(results.getString("CurrencyRateID"));
       so.setSubTotal(results.getFloat("SubTotal"));
       so.setTaxAmt(results.getFloat("TaxAmt"));
       so.setFreight(results.getFloat("Freight"));
       so.setTotalDue(results.getFloat("TotalDue"));
       so.setComment(results.getString("Comment"));
       so.setModifiedDate(results.getString("ModifiedDate"));
       salesOrderList.add(so);
       
}
      
      session.setAttribute("salesOrderList",salesOrderList);
      // Clean up
      conn.close();
      
      mv.setViewName("index");
    } 
    
    } catch (Exception e) {
    System.out.println(e.getMessage());
    }  
       
            return mv;
    }
    
}
