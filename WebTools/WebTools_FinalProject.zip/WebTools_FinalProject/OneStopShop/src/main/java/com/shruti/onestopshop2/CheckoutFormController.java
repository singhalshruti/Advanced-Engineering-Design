package com.shruti.onestopshop2;



import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.shruti.spring.dao.OrderDAO;
import com.shruti.spring.pojo.Category;
import com.shruti.spring.pojo.Customer;
import com.shruti.spring.pojo.Order;
import com.shruti.spring.pojo.OrderItem;
import com.shruti.spring.pojo.Product;



@Controller
public class CheckoutFormController
{
	
	
	
	@RequestMapping(value="/checkout.htm")
    protected String doSubmitAction(Model model,HttpServletRequest request) throws Exception
    {   
        try
        {  	
        	System.out.println("inside checkout controller");

            HttpSession session =request.getSession();
            HashSet<OrderItem> cartlist;
            cartlist = (HashSet<OrderItem>) session.getAttribute("cart");
            Customer cust= (Customer)session.getAttribute("user");
            OrderDAO orderDao= new OrderDAO();
        	System.out.println("inside checkout controller" + cust);

        	
            Order order= orderDao.create(cartlist,cust);
            
            cust.addOrder(order);
            //DAO.close();
        	System.out.println("Order created successfully" );
        	
        	//for order summary purpose
        	session.setAttribute("order", order);
        	session.setAttribute("cart", null);
            
        	return "redirect:/orderSuccess";
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
		return "customerLoggedIn";
        
    }
	@RequestMapping(value="/orderSuccess",method = RequestMethod.GET)
	public String initializeCart(Model model) {

		return "orderSuccess";
	}
	
	@RequestMapping(value="/orderSummary",method = RequestMethod.GET)
	public String initializeOrder(Model model) {

		return "orderSummary";
	}
	
	
}