package com.shruti.spring.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="product")
public class Product {

	@Id
	@GeneratedValue
	@Column(name = "productID")
	private long productID;
	
	@Column(name = "productName")
	private String productName;
	
	@Column(name = "description")
	private String description;
	
	@Column(name = "price")
	private float price;
	
	@Column(name = "quantity")
	private int quantity;
	
	@Transient //will stored in product table
    private String postedBy;
	
	//keep one and comment other and vice-versa to explain the result in console
    @ManyToOne(fetch=FetchType.EAGER)
	@JoinColumn(name="supplier")
    private Supplier supplier;
    
    @Transient //will stored in product table
    private String category_name;
    
    @JoinColumn(name="categoryid")
    private long category;

 

	public Product( String productName, String description, float price, int quantity,
			Supplier supplier, long category,String category_name) {
		
		
		this.productName = productName;
		this.description = description;
		this.price = price;
		this.quantity = quantity;
	
		this.supplier = supplier;
		this.category_name = category_name;
		this.category = category;
	}

	Product() {
    }

    public long getProductID() {
		return productID;
	}

	public void setProductID(long productID) {
		this.productID = productID;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public float getPrice() {
		return price;
	}

	public void setPrice(float price) {
		this.price = price;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Supplier getSupplier() {
		return supplier;
	}

	public void setSupplier(Supplier supplier) {
		this.supplier = supplier;
	}

	public String getCategory_name() {
		return category_name;
	}

	public void setCategory_name(String category_name) {
		this.category_name = category_name;
	}

	public String getPostedBy() {
        return this.postedBy;
    }

    public void setPostedBy(String pb) {
        this.postedBy = pb;
    }

	public long getCategory() {
		return category;
	}

	public void setCategory(long category) {
		this.category = category;
	}
	
	
}