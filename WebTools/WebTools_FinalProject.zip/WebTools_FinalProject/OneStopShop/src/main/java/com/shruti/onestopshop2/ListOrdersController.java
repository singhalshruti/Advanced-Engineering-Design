package com.shruti.onestopshop2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shruti.spring.dao.CategoryDAO;
import com.shruti.spring.dao.OrderDAO;
import com.shruti.spring.pojo.Category;
import com.shruti.spring.pojo.Customer;
import com.shruti.spring.pojo.Order;
import com.shruti.spring.pojo.OrderItem;
import com.shruti.spring.pojo.Product;
import com.shruti.spring.pojo.User;

@Controller
@RequestMapping("/viewOrders")
public class ListOrdersController{

	@RequestMapping(method=RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Order> orderList = null;
		List<Order> ordList = new ArrayList<Order>();
		List<OrderItem> prodList= new ArrayList<OrderItem>();
		HttpSession session= request.getSession();
		Customer u= (Customer) session.getAttribute("user");
		
		System.out.println("Hanuman here hi");
		
		try {
			OrderDAO orders = new OrderDAO();
            orderList = orders.list(u);

            Iterator orderIterator = orderList.iterator();
    		System.out.println("Order list " + orderIterator);


            while (orderIterator.hasNext())
            {
        		System.out.println("Order list i am here" + orderIterator);

            	
                Order order = (Order) orderIterator.next();
                ordList.add(order);
                /*Iterator prodIterator = order.get

                while (prodIterator.hasNext())
                {
                    Product product = (Product) prodIterator.next();
                    prodList.add(product);
            		System.out.println("Order list i am here inner most loop" + orderIterator);

                }*/
            }
            //DAO.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

         //mv = new ModelAndView("viewOrders", "products", prodList);
         ModelAndView mv= new ModelAndView("viewOrders","ordList", ordList);
        return mv;
    }
	
	
	
	
}