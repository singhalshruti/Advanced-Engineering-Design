package com.shruti.spring.pojo;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;


@Entity
@Table(name="user")
@Inheritance(strategy=InheritanceType.JOINED)//table per subclass
public class User{
	
	public User(){}

	@Id
	@GeneratedValue
	@Column(name = "userID", unique=true, nullable = false)
	private long userID;
	
	@Column(name = "firstName")
	private String firstName;
	
	@Column(name ="lastName")
	private String lastName;
	
	@Column(name ="address")
	private String address;
	
	@Column(name ="mobileNo")
	private long mobileNo;
	
	@Column(name="role")
	private String role;
	
	@Column(name="emailId")
	private String emailId;
    
	@Column(name="password")
	private String password;
	
	public User(String emailId, String password) {
		
		this.emailId = emailId;
		this.password = password;
		
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getUserID() {
		return userID;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public void setUserID(long userID) {
		this.userID = userID;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getRole() {
	return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

}