package com.shruti.spring.dao;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.shruti.spring.pojo.Customer;
import com.shruti.spring.pojo.Order;
import com.shruti.spring.pojo.OrderItem;
import com.shruti.spring.pojo.Product;



public class OrderDAO extends DAO {

    public Order get(String id) throws Exception {
        try {
            begin();
            Query q=getSession().createQuery("from OrderTable where orderid= :id");
            q.setString("orderid",id);
            Order order=(Order)q.uniqueResult();
            commit();
            return order;
        } catch (HibernateException e) {
            rollback();
            throw new HibernateException("Could not obtain the named order: " + id + " " + e.getMessage());
        }
    }

    public List list(Customer u) throws Exception {
        try {
            begin();
            System.out.println("Customer " +u.getUserID());
            long cust=u.getUserID();
            Query q = getSession().createQuery("from Ordertable where customer= :customer");
            q.setEntity("customer",u);
            List list = q.list();
            commit();
            return list;
        } catch (HibernateException e) {
            rollback();
            System.out.println(e);

            throw new HibernateException("Could not list the orders", e);
        }
    }

    public Order create(HashSet<OrderItem> cartlist, Customer cust) throws Exception {
        try {
        	
        	System.out.println("inside Order DAO");
            begin();
            
            System.out.println("inside order DAO "+ cust);
            Order o = new Order(cust);
            for(OrderItem oi:cartlist){
                System.out.println("inside order DAO orderitem "+ oi);
                OrderItem orderItem=new OrderItem();
                orderItem=oi;
                orderItem.setOrder(o);
                getSession().save(orderItem);
            	o.addOrderItem(orderItem);
            	
            	
            }
            
            //o.setOrderItems(orderItems);
            System.out.println("inside order DAO "+o);
            
            getSession().save(o);
            commit();
            return o;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create the category", e);
            throw new HibernateException("Exception while creating order: " + e.getMessage());
        }
        
    }

    public void save(Order order) throws Exception {
        try {
            begin();
            getSession().update(order);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new HibernateException("Could not save the Order", e);
        }
    }

    public void delete(Order order) throws Exception {
        try {
            begin();
            getSession().delete(order);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new HibernateException("Could not delete the Order", e);
        }
    }
}