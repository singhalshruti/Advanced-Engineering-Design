package com.shruti.spring.pojo;


import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

@Entity
@Table(name="ordertable")
public class Order{

	@Id 
	@GeneratedValue
	@Column(name="orderID", nullable = false)
    private long orderID;
	
    @Column(name = "orderedDate")
    private Date orderedDate;
	
	@OneToMany (fetch=FetchType.LAZY, mappedBy="order")
	private Set<OrderItem> orderItems = new HashSet<OrderItem>();
	
	
	 public void addOrderItem(OrderItem o) {
		 getOrderItems().add(o);
	    }

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn(name="customer")
    private Customer customer;
	
    public Order() {
    }

    public Date getOrderedDate() {
		return orderedDate;
	}

	public void setOrderedDate(Date orderedDate) {
		this.orderedDate = orderedDate;
	}

	

	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public long getOrderID() {
		return orderID;
	}

	public void setOrderID(long orderID) {
		this.orderID = orderID;
	}


	public Set<OrderItem> getOrderItems() {
		return orderItems;
	}

	public void setOrderItems(Set<OrderItem> orderItems) {
		this.orderItems = orderItems;
	}

	public Order(Customer c ) {
		//this.orderItem = orderItem;
		this.customer=  c;
		Date date=new Date();
		setOrderedDate(date);
		
				
		// shruti new
		//product = new HashSet<Product>();
	} 
}