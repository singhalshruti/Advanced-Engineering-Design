package com.shruti.onestopshop2;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shruti.spring.dao.UserDAO;
import com.shruti.spring.pojo.User;



/**
 * Handles requests for the application home page.
 */
@Controller
public class LoginController {
	
 
	@RequestMapping(value="/",method = RequestMethod.GET)
	public String initializeForm(Model model ) {	
		return "home";	
	}
	
	
	
	@RequestMapping(value="/logout")
	public String logout(Model model,HttpServletRequest request) {	
		HttpSession session=request.getSession();
		session.invalidate();
		return "home";
		
	}
	
	//sigup page
	@RequestMapping(value="/signup",method = RequestMethod.POST)
	protected String doSubmitAction(@ModelAttribute("user") User user, BindingResult result) 
			//throws AdException 
	{
		
		try {
			System.out.println("shruti here!");
			UserDAO ud = new UserDAO();
			System.out.println("hello shruti"+ user.getEmailId()+" "+user.getPassword() +" "+ user.getFirstName());
			User u = ud.create(user.getEmailId(), user.getPassword(), user.getFirstName(), user.getLastName(),user.getAddress(), user.getMobileNo(), user.getRole());
			//System.out.print("test1");
			System.out.println("1");
			if(u.getRole().equalsIgnoreCase("supplier")|| u.getRole().equalsIgnoreCase("customer")){
				
				return "login";
			}
			else return "home";
			// DAO.close();
		} catch (Exception e) {
			System.out.println("Exception: " + e.getMessage());
			return "home";
		}

		
	}

	@RequestMapping(value="/signup",method = RequestMethod.GET)
	public String initializeForm(@ModelAttribute("user") User user) {
		return "signup";
	}
	
	
	//login
	@RequestMapping(value="/login",method = RequestMethod.POST)
	protected String submitForm(@ModelAttribute("user") User user, BindingResult result, HttpServletRequest request) throws Exception 
	//throws AdException 
		{			
				try {
					
					UserDAO userDao = new UserDAO();
					System.out.println("hello  "+user.getEmailId());
					User u1 = userDao.checkUser(user.getEmailId(),user.getPassword());
					System.out.println("Call of Duty");

					HttpSession session = request.getSession();
					
					session.setAttribute("name", u1.getFirstName());
					session.setAttribute("user", u1);
					if(u1.getRole().equalsIgnoreCase("supplier")){
						
					return "supplierLoggedIn";
					}
					else if(u1.getRole().equalsIgnoreCase("customer")){
						
						return "customerLoggedIn";
						}
					else  
					{
					return "home";
					}
				}
		    		
				catch(Exception e) {
					System.out.println("Exception: " + e.getMessage());
					return "signup";
				}

				
					
	
	
	}
	
	@RequestMapping(value="/login",method = RequestMethod.GET)
	public String initializeHome(@ModelAttribute("user") User user,HttpServletRequest request ) {
		

		HttpSession session = request.getSession();
		if(null == session.getAttribute("user")){  
			// User is not logged in.  
			return "login";
			}
		else{

		session = request.getSession();
		User u= (User) session.getAttribute("user");
		if (u.getRole().equalsIgnoreCase(("customer"))){
						
						return "customerLoggedIn";
						}
		else if (u.getRole().equalsIgnoreCase(("supplier"))){
			
			return "supplierLoggedIn";
			}
		}return "login";
		}

	}

