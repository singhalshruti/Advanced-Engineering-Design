package com.shruti.spring.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;

import org.springframework.beans.factory.annotation.Autowired;

@Entity
@Table(name = "supplier")
@PrimaryKeyJoinColumn(name="userID")
public class Supplier extends User {

	
	@Autowired
	@OneToMany(fetch=FetchType.LAZY, mappedBy="supplier")
	private Set<Product> product = new HashSet<Product>();


	public Set<Product> getProduct() {
		return product;
	}

	
	public void setProduct(Set<Product> product) {
		this.product = product;
	}

	public Supplier(Set<Product> product) {
		super();
		//Shruti New
		//this.product = product;
		product = new HashSet<Product>();
	}

	public Supplier() {	
		
	}

}
