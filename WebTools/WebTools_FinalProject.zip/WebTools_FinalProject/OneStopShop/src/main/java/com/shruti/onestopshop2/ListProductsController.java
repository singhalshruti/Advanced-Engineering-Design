package com.shruti.onestopshop2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.shruti.spring.dao.CategoryDAO;
import com.shruti.spring.pojo.Category;
import com.shruti.spring.pojo.Product;

@Controller
@RequestMapping("/viewProducts")
public class ListProductsController{

	@RequestMapping(method=RequestMethod.GET)
    protected ModelAndView handleRequestInternal(HttpServletRequest request, HttpServletResponse response) throws Exception {
		List<Category> categoryList = null;
		List<Category> catList = new ArrayList<Category>();
		List<Product> prodList= new ArrayList<Product>();
		System.out.println("Hanuman here");
		
		try {
            CategoryDAO categories = new CategoryDAO();
            categoryList = categories.list();

            Iterator categIterator = categoryList.iterator();
    		System.out.println("Category list " + categIterator);


            while (categIterator.hasNext())
            {
                Category category = (Category) categIterator.next();

                Iterator advIterator = category.getProducts().iterator();

                while (advIterator.hasNext())
                {
                    Product product = (Product) advIterator.next();
                    prodList.add(product);
                }
            }
            //DAO.close();
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }

        ModelAndView mv = new ModelAndView("viewProducts", "products", prodList);
        return mv;
    }
	
	
	
	
}