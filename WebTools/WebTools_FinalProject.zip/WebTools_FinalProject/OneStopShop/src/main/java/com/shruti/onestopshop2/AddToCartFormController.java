package com.shruti.onestopshop2;



import java.util.HashSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shruti.spring.dao.ProductDAO;
import com.shruti.spring.pojo.OrderItem;
import com.shruti.spring.pojo.Product;



@Controller
public class AddToCartFormController
{
	
	
	
	@RequestMapping(value="/addtocart.htm")
    protected String addToCartAction(Model model,HttpServletRequest request) throws Exception
    { 
        try
        {
            System.out.println("inside cart controller");

           ProductDAO productDao= new ProductDAO();
           HttpSession session =request.getSession();
           
           HashSet<OrderItem> cart;
           if (session.getAttribute("cart") != null) {
               cart = (HashSet<OrderItem>) session.getAttribute("cart");
           } else {
               cart = new HashSet<OrderItem>();
           }
           System.out.println("flag 2"+request.getParameter("itemid"));

           String id = String.valueOf((request.getParameter("itemid")));
           System.out.println("flag 2"+id);

           Product product = productDao.get(id);
           OrderItem oi = new OrderItem();
           oi.setProduct(product);
           cart.add(oi);
           
           float total = 0;
           for (OrderItem o : cart) {
               total = total + o.getProduct().getPrice();
               System.out.println("o "+o.getProduct().getProductName() );
           }
           
           
           session.setAttribute("cart", cart);
           session.setAttribute("total", total);
           System.out.println("saved to cart I think");
           
           return "redirect:/cart";
        }
        catch (Exception e)
        {
            System.out.println(e.getMessage());
        }
        return "cart";
    }
	
	@RequestMapping(value="/cart",method = RequestMethod.GET)
	public String initializeCart(Model model) {

		return "cart";
	}
    


}


