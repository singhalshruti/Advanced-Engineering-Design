package com.shruti.spring.dao;

import java.util.HashSet;
import java.util.Set;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.shruti.spring.pojo.Customer;
import com.shruti.spring.pojo.Order;
import com.shruti.spring.pojo.Supplier;
import com.shruti.spring.pojo.User;

public class UserDAO extends DAO {

    public UserDAO() {
    }

    public User get(String emailId)
            throws Exception {
        try {
            begin();
            Query q = getSession().createQuery("from User where emailId = :emailId");
            q.setString("emailId", emailId);
            User user = (User) q.uniqueResult();
            commit();
            return user;
        } catch (HibernateException e) {
            rollback();
            System.out.println("Shruti"+e);
            return null;
        }
    }
    
  

    public User create(String emailId,String password, String firstName, String lastName, String address, long mobileNo, String role)
  //throws AdException 
    {
        try {
            System.out.println("shruti inside DAO");

            begin();
            System.out.println("shruti inside DAO");
            
            if (role.equalsIgnoreCase("supplier")){
            
            Supplier s= new Supplier();
            
            s.setFirstName(firstName);
            s.setLastName(lastName);
            s.setAddress(address);
            s.setMobileNo(mobileNo);
            s.setRole(role);
            s.setEmailId(emailId);
            s.setPassword(password);
            getSession().save(s);
            
            commit();
            return s;
            }
            else if (role.equalsIgnoreCase("customer")){
            	System.out.println("shruti inside DAO");
            	
            	Customer c = new Customer();        	

                c.setFirstName(firstName);
                c.setLastName(lastName);
                c.setAddress(address);
                c.setMobileNo(mobileNo);
                c.setRole(role);
                c.setEmailId(emailId);
                c.setPassword(password);
                getSession().save(c);
                commit();
                return c;
            }
            
            
        } catch (HibernateException e) {
            rollback();
            return null;
            //throw new AdException("Exception while creating user: " + e.getMessage());
        }
		return null;
		
    }

    public void delete(User user)
            //throws AdException 
    {
        try {
            begin();
            getSession().delete(user);
            commit();
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not delete user " + user.getFirstName(), e);
        }
    }
    
    
    public User checkUser(String eId, String p)throws Exception{
    	try{
    		System.out.println("hello Sai babaji "+eId+p);

    		
    			
    			Query q = getSession().createQuery(" from User where emailId =:email and password =:pass");
               

            
            q.setString("email", eId);
            q.setString("pass", p);
    		System.out.println("hello Sai baba2"+q.getQueryString());
            System.out.println("hello Sri Ram"+eId+p);

            User user = (User) q.uniqueResult();
    		System.out.println(user.getFirstName());
            return user;
       }
         
     catch (HibernateException e) {
    	 System.out.println("Shruti"+e);
        rollback();   
		return null;
     }
		
    }

	private Query createQuery(String string) {
		// TODO Auto-generated method stub
		return null;
	}	
    	
    }
