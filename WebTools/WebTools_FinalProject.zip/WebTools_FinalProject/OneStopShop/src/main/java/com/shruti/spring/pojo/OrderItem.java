package com.shruti.spring.pojo;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Transient;

@Entity
@Table(name="orderItem")
public class OrderItem {

	@Id
	@GeneratedValue
	@Column(name = "orderItemID")
	private long orderItemID;
	
	@OneToOne(cascade = CascadeType.ALL) 
	private Product product;

	@ManyToOne(fetch=FetchType.LAZY)
	@JoinColumn
    private Order order;
	

	public OrderItem() {
		
    }


	public long getOrderItemID() {
		return orderItemID;
	}


	public void setOrderItemID(long orderItemID) {
		this.orderItemID = orderItemID;
	}


	public Product getProduct() {
		return product;
	}


	public void setProduct(Product product) {
		this.product = product;
	}


	public Order getOrder() {
		return order;
	}


	public void setOrder(Order order) {
		this.order = order;
	}

  

	
}