package com.shruti.spring.dao;

import org.hibernate.HibernateException;
import org.hibernate.Query;

import com.shruti.spring.pojo.Category;
import com.shruti.spring.pojo.Product;
import com.shruti.spring.pojo.Supplier;



public class ProductDAO extends DAO {

    public Product create(String productName, String description, float price, int quantity,
			Supplier supplier, long category,String category_name)
            throws Exception {
        try {
            begin();
            Product product = new Product(productName, description, price, quantity, supplier, category, category_name);
            getSession().save(product);
            commit();
            return product;
        } catch (HibernateException e) {
            rollback();
            //throw new AdException("Could not create advert", e);
            throw new HibernateException("Exception while creating product: " + e.getMessage());
        }
    }

    public void delete(Product product)
            throws Exception {
        try {
            begin();
            getSession().delete(product);
            commit();
        } catch (HibernateException e) {
            rollback();
            throw new HibernateException("Could not delete product", e);
        }
    }
    
    public Product get(String id) throws Exception {
        try {
            begin();
            
            System.out.println("flag 3");

            Query q=getSession().createQuery("from Product where productID= :id");
            
            q.setString("id",id);
            Product product=(Product)q.uniqueResult();
            commit();
            return product;
        } catch (HibernateException e) {
            rollback();
            throw new HibernateException("Could not obtain the named product " +  e.getMessage());
            
        }
    }
}