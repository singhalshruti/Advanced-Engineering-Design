package com.shruti.onestopshop2;



import java.util.HashSet;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.omg.CORBA.SystemException;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shruti.spring.dao.ProductDAO;
import com.shruti.spring.pojo.OrderItem;
import com.shruti.spring.pojo.Product;
import com.shruti.spring.pojo.User;



@Controller
//@RequestMapping(value="/removefromcart.htm")
public class RemoveFromCartFormController
{@RequestMapping(value="/removefromcart")
protected String removeFromCart(Model model,HttpServletRequest request) throws Exception
{ 
    try
    {
        System.out.println("inside remove from cart controller");

       ProductDAO productDao= new ProductDAO();
       HttpSession session =request.getSession();
       
       HashSet<OrderItem> cart;
       cart = (HashSet<OrderItem>) session.getAttribute("cart");
       
       System.out.println("flag 2"+request.getParameter("itemid"));

       String id = String.valueOf((request.getParameter("itemid")));
       System.out.println("flag 2"+id);

       Product product = productDao.get(id);
       OrderItem oi = new OrderItem();
       oi.setProduct(product);
       cart.remove(oi);
       
       float total = 0;
       for (OrderItem o : cart) {
           total = total + o.getProduct().getPrice();
           System.out.println("o "+o.getProduct().getProductName() );
       }
       
       
       
       session.setAttribute("total", total);
       System.out.println("removed from cart I think");
       
       return "viewProducts";
    }
    catch (Exception e)
    {
        System.out.println(e.getMessage());
    }
    return "viewProducts";
}
	
	
    }

