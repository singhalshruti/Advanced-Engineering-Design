package com.shruti.spring.pojo;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.OneToMany;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;


@Entity
@Table(name="customer")
@PrimaryKeyJoinColumn(name="userID")
public class Customer extends User{

	@OneToMany(fetch=FetchType.LAZY, mappedBy="customer")
	private Set<Order> order = new HashSet<Order>();
	
	public Customer() {
		
	}

	public Set<Order> getOrder() {
		return order;
	}


	public void setOrder(Set<Order> order) {
		this.order = order;
	}

	 public void addOrder(Order order) {
	        getOrder().add(order);
	    }


	public Customer(Set<Order> order) {
		super();
		order = new HashSet<Order>();
	}
	 
	
}