package com.shruti.onestopshop2;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.shruti.spring.dao.CategoryDAO;
import com.shruti.spring.dao.ProductDAO;
import com.shruti.spring.dao.UserDAO;
import com.shruti.spring.pojo.Category;
import com.shruti.spring.pojo.Product;
import com.shruti.spring.pojo.Supplier;



@Controller
public class AddProductFormController {

	@RequestMapping(value="/supplierLoggedIn",method = RequestMethod.GET)
	public String initializeForm(Model model ) {	
		return "supplierLoggedIn";
		
	}
	
	@RequestMapping(value="/addProduct",method=RequestMethod.POST)
    protected String doSubmitAction(@ModelAttribute("product")Product product,BindingResult result) throws Exception{

		
    	
    	
        String emailId = product.getPostedBy();   //get posting user from addproduct
        String categoryTitle = product.getCategory_name();   //get category user from addproduct
      //  String name = product.getProductName();      //get product title user from addproduct
      //  String desc = product.getDescription();    //get user message from addproduct

        try {
            UserDAO users = new UserDAO();
            CategoryDAO categories = new CategoryDAO();
            ProductDAO prod = new ProductDAO();
            
            //searching from database
            Supplier supplier = (Supplier) users.get(emailId);

            //searching from database
            Category category = categories.get(categoryTitle);

            //insert a new products
            Product p = prod.create(product.getProductName(),product.getDescription(), product.getPrice(), product.getQuantity(), supplier,category.getId(),category.getTitle());

            category.addProduct(p);
            categories.save(category);

            
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
        return "supplierLoggedIn";
    }
    
	@RequestMapping(value="/addProduct",method=RequestMethod.GET)
    public String initializeForm(@ModelAttribute("product")Product product, BindingResult result, HttpServletRequest request) { 
	
		List<Category> categoryList = null;
		//List<Category> catList = new ArrayList<Category>();
		
		System.out.println("Hanuman here");
		
		try {
            CategoryDAO categories = new CategoryDAO();
            categoryList = categories.list();
                  
            /*
            Iterator categIterator = categoryList.iterator();
            while (categIterator.hasNext())
            {
                Category category = (Category) categIterator.next();
                System.out.println("Product Category:"+category);
                catList.add(category);
            }
            */
            
            HttpSession session=request.getSession();
    		session.setAttribute("categoryList", categoryList);
    		System.out.println("Ganpati bappa"+categoryList);

		}
		catch (Exception e) {
            System.out.println(e.getMessage());
        }
		
        return "addProduct"; 
    } 
}