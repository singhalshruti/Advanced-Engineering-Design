/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.controller;

import com.myapp.bean.MovieBean;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Rakesh
 */
public class MovieList extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            String keyword = request.getParameter("keyword");
            String searchBy = request.getParameter("radio1");
            
            HttpSession session = request.getSession();
            Connection conn = establishConnectionJDBC();
            
            
             String querySearch = "Select * from movies where "+searchBy+" like ?"; 
             PreparedStatement msgStmt = conn.prepareStatement(querySearch);
             msgStmt.setString(1, "%"+keyword+"%");
             ResultSet resultMovies = msgStmt.executeQuery();
             ArrayList<MovieBean> movieBeanList = new ArrayList<>();
            
            
             while(resultMovies.next()){
                
                    MovieBean movieBean = new MovieBean();
                    movieBean.setTitle(resultMovies.getString("title"));
                    movieBean.setActor(resultMovies.getString("actor"));
                    movieBean.setActress(resultMovies.getString("actress")); 
                    movieBean.setGenre(resultMovies.getString("genre"));
                    movieBean.setYr(resultMovies.getInt("yr"));
                    movieBeanList.add(movieBean);
                    
                }
                session.setAttribute("keyword", keyword);
                session.setAttribute("movieList", movieBeanList);
                RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/Views/MovieList.jsp");
                rd.forward(request,response); 
             
            /* TODO output your page here. You may use following sample code. */
            
        }
        
        catch(Exception e){
            System.out.println(e.getMessage());
        }
    }
    
    
        protected Connection establishConnectionJDBC()
            throws IOException, ClassNotFoundException, SQLException {
    
        Connection connection = null;
        
        try{
        
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(ClassNotFoundException e){
        
            e.printStackTrace();
        }
        
        try{
        
            connection = DriverManager.getConnection("jdbc:MySQL://127.0.0.1:3306/moviedb","root","root");
        }
        catch(SQLException e){
            e.printStackTrace();
        }
        
            return connection;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MovieList.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MovieList.class.getName()).log(Level.SEVERE, null, ex);
        }
       
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(MovieList.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(MovieList.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
