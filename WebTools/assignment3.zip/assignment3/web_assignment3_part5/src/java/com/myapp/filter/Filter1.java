/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.filter;

import java.io.IOException;
import java.util.Enumeration;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Rakesh
 */
public class Filter1 implements Filter{
    
    private ServletContext context;
     
    @Override
    public void init(FilterConfig fconfig)throws ServletException{
        this.context=fconfig.getServletContext();
        this.context.log("RequestLoggingFilter initialized");
    }
     @Override
     public void doFilter(ServletRequest request, ServletResponse response, FilterChain fc) throws IOException, ServletException {
        
        HttpServletRequest req = (HttpServletRequest) request;
        HttpSession session = req.getSession();
        String action=request.getParameter("action");
        
            int num = (int)session.getAttribute("no");
        for(int i=1; i<=num;i++){
            String isbn = request.getParameter("isbn"+i+"").replaceAll("/[^a-zA-Z\\d/.]/g", "").replaceAll("\\s+", "+").trim();
            String title = request.getParameter("title"+i+"").replaceAll("[^a-zA-Z\\d@/.]", "").replaceAll("\\s+", "+").trim();
            String author = request.getParameter("author"+i+"").replaceAll("[^a-zA-Z\\d@/.]", "").replaceAll("\\s+", "+").trim();
           
            session.setAttribute("isbn"+i+"", isbn);
            session.setAttribute("title"+i+"", title);
            session.setAttribute("author"+i+"", author);
        }
        
        
       fc.doFilter(request, response);
    }
  @Override
    public void destroy() {
        // throw new UnsupportedOperationException("Not supported yet."); 
    }
 
}
   