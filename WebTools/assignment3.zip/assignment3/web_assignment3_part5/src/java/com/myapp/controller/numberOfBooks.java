/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.myapp.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author Rakesh
 */
@WebServlet(name = "numberOfBooks", urlPatterns = {"/nob.htm"})
public class numberOfBooks extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException, ClassNotFoundException, SQLException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
           
           HttpSession session = request.getSession();
           if (session.getAttribute("no") != null) {
            int count=0;
            System.out.println(request.getParameter("no"));
            int numb = (int) session.getAttribute("no");
            Connection conn = establishConnectionJDBC();
            String[] ISBN=request.getParameterValues("ISBN");
            String[] title=request.getParameterValues("BookTitle");
            String[] author=request.getParameterValues("Author");
                String[] cost = request.getParameterValues("Price");
            
            for (int i=0; i<numb; i++){
                 float f= Float.parseFloat(cost[i]);
                 String queryMovie = "INSERT INTO books (isbn,title,author,price)"
                    + "values ('" + ISBN[i] + "','" + title[i] + "','" + author[i] + "',"
                    + f + ")";
              
            Statement statement = conn.createStatement();
            int result = statement.executeUpdate(queryMovie);
            count++;
            }
            
            session.setAttribute("count", count);
            session.setAttribute("no", null);
            
            if(count==numb){
                RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/Views/BooksAdded.jsp");
                rd.forward(request, response);
            }
           }
               
           else{
              
               int no=Integer.parseInt(request.getParameter("no"));
               session.setAttribute("no", no);
               RequestDispatcher rd = request.getRequestDispatcher("/WEB-INF/Views/BookDetails.jsp");
               rd.forward(request,response); 
           }
               
            
        
    }   catch(Exception e){
            System.out.println(e.getMessage());
    }
    
    }
    
    protected Connection establishConnectionJDBC()
            throws IOException, ClassNotFoundException, SQLException {
    
        Connection connection = null;
        
        try{
        
            Class.forName("com.mysql.jdbc.Driver");
        }
        catch(ClassNotFoundException e){
        
            e.printStackTrace();
        }
        
        try{
        
            connection = DriverManager.getConnection("jdbc:MySQL://127.0.0.1:3306/booksdb","root","root");
        }
        catch(SQLException e){
            e.printStackTrace();
        }
   
       
        
            return connection;
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(numberOfBooks.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(numberOfBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        try {
            processRequest(request, response);
        } catch (ClassNotFoundException ex) {
            Logger.getLogger(numberOfBooks.class.getName()).log(Level.SEVERE, null, ex);
        } catch (SQLException ex) {
            Logger.getLogger(numberOfBooks.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
