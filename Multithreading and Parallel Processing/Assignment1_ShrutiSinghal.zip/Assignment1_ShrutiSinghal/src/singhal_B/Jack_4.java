/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singhal_B;


import java.util.LinkedList;

/**
 *
 * @author User
 */
public class Jack_4 extends Thread{
    protected LinkedList<Integer> inspectedListJack;
    protected LinkedList<Integer> list;
    public Thread t;
    
	public Jack_4(LinkedList<Integer> list, LinkedList<Integer> inspectedListJack) {
		this.list = list;
                this.inspectedListJack = inspectedListJack;
                t=new Thread(this);
	}
	
	/**
	 * Update <code>partialMax</code> until the list is exhausted.
	 */
	public void run() {
            int number;
            int sum=0;
            while (true) {
			// check if list is not empty and removes the head
			// synchronization needed to avoid atomicity violation
			synchronized(list) {
				if (list.isEmpty())
					return; // list is empty
				number = list.remove();
			}
			if(sum>21)
			// update partialMax according to new value
			// TODO: IMPLEMENT CODE HERE
                        {
                            return;
                        }
                        else{
                            inspectedListJack.add(number);
                            sum= sum + number;
                        }
            }	
	}
	public LinkedList<Integer> getJack() {
		return inspectedListJack;
	}
}
