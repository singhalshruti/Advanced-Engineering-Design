/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package singhal_B;


import java.util.LinkedList;

/**
 *
 * @author User
 */
public class Order_3 extends Thread{
    protected LinkedList<Integer> inspectedListOrder;
    protected LinkedList<Integer> list;
    public Thread t;
    
	public Order_3(LinkedList<Integer> list, LinkedList<Integer> inspectedListOrder) {
		this.list = list;
                this.inspectedListOrder = inspectedListOrder;
                t=new Thread(this);
	}
	
	/**
	 * Update <code>partialMax</code> until the list is exhausted.
	 */
	public void run() {
            int number;
            int prev=0;
            while (true) {
			
			// check if list is not empty and removes the head
			// synchronization needed to avoid atomicity violation
			synchronized(list) {
				if (list.isEmpty())
					return; // list is empty
				number = list.remove();
			}
			if(number>prev )
			// update partialMax according to new value
			// TODO: IMPLEMENT CODE HERE
                        { 
                           //System.out.println("The number is :"+ number );
                           inspectedListOrder.add(number);
                           prev=number;
                        }
                }
		}
	public LinkedList<Integer> getOrder() {
		return inspectedListOrder;
	}
}
