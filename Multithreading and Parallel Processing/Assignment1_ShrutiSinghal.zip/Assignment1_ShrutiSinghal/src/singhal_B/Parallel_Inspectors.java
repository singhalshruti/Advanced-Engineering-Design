package singhal_B;
/**
 *
 * @author User
 */

import java.util.*;
import java.util.concurrent.CountDownLatch;


/**
 * This class runs <code>numThreads</code> instances of
 * <code>ParallelMaximizerWorker</code> in parallel to find the maximum
 * <code>Integer</code> in a <code>LinkedList</code>.
 */
public class Parallel_Inspectors {
    
        int numThreads;       
//	ArrayList<Even_1> even; // = new ArrayList<ParallelMaximizerWorker>(numThreads);

	public Parallel_Inspectors(int numThreads) {
                this.numThreads = numThreads;
        }

	public static void main(String[] args) {
		int numThreads = 4; // number of threads for the maximizer
		int numElements = 10000; // number of integers in the list
		LinkedList<Integer> masterList= new LinkedList<Integer>(); //master list for every computation
                
		Parallel_Inspectors maximizer = new Parallel_Inspectors(numThreads);
		LinkedList<Integer> list = new LinkedList<Integer>();
		Random r = new Random();
		// populate the list
		// TODO: change this implementation to test accordingly
		for (int i=0; i<numElements; i++) {
                    int rand = r.nextInt(20); //selecting random numbers from under 20
                    //System.out.println(rand);
                    list.add(rand);
                }
                masterList=(LinkedList) list.clone();
                // run the maximizer for 10 computations
                for (int i=0; i<10; i++) {
                        int n= i+1;
                        System.out.println("Computation Number : "+n);
                try {
                    System.out.println("the method is complete : " +maximizer.inspector(list));
                    list=(LinkedList)masterList.clone();//reset the empty list to original generated list
                } 
                catch (InterruptedException e) {
			e.printStackTrace();
		}
                }
	}
	
	/**
	 * Finds the maximum by using <code>numThreads</code> instances of
	 * <code>ParallelMaximizerWorker</code> to find partial maximums and then
	 * combining the results.
	 * @param list <code>LinkedList</code> containing <code>Integers</code>
	 * @return Maximum element in the <code>LinkedList</code>
	 * @throws InterruptedException
	 */
	public int inspector(LinkedList<Integer> list) throws InterruptedException {
                LinkedList<Integer> inspectedListEven = new LinkedList<Integer>();
                LinkedList<Integer> inspectedListOdd = new LinkedList<Integer>();
                LinkedList<Integer> inspectedListOrder = new LinkedList<Integer>();
                LinkedList<Integer> inspectedListJack = new LinkedList<Integer>();
		
                Even_1 even= new Even_1(list,inspectedListEven );
                even.t.start();
                
                Odd_2 odd= new Odd_2(list,inspectedListOdd);
                odd.t.start();
                
                Order_3 order= new Order_3(list,inspectedListOrder);
                order.start();
                
                Jack_4 jack= new Jack_4(list,inspectedListJack);
                jack.start();
                
                even.t.join();
                odd.t.join();
                order.t.join();
                jack.t.join();
                
                inspectedListEven = even.getEven();
                inspectedListOdd = odd.getOdd();
                inspectedListOrder = order.getOrder();
                inspectedListJack = jack.getJack();
		
                System.out.println("The even list generated is:"+ inspectedListEven);
                System.out.println("The odd list generated is:"+ inspectedListOdd);
                System.out.println("The order list generated is:"+ inspectedListOrder);
                System.out.println("The Jack list generated is:"+ inspectedListJack);
                
                return 1;
                }    
		
        
}
