package singhal;

public interface Client extends Runnable
{
	String name();
}