/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hw3;

import java.util.LinkedList;
import java.util.concurrent.CountDownLatch;

/**
 *
 * @author ShrutiSinghal
 */
public class Order {
	public final CountDownLatch cdl;
	public final LinkedList<Food> order;
	public final int orderNum;
	

	public Order(CountDownLatch cdl, LinkedList<Food> order, int orderNum) {
	
		this.cdl = cdl;
		this.order = order;
		this.orderNum = orderNum;
	}
}